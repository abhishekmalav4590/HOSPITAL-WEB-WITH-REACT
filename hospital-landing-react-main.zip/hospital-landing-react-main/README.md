# Hospital Landing Page using React JS

A beautiful hospital landing page built with React JS

![screenshot](/screenshot.png)

## Tech Stack

 React JS

## Installation

Download the zip file. In the project folder:

```bash
  npm install
  npm start
```

## Authors

- [@realtutorialspoint](https://www.github.com/realtutorialspoint)
