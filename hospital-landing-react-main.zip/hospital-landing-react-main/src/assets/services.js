import vaccine from "../assets/images/vaccine-icon.png"
import selfcare from "../assets/images/selfcare.png"
import laboratory from "../assets/images/laboratory.png"
import treatment from "../assets/images/treatment.png"
import pethealth from "../assets/images/pethealth.png"
import symptoms from "../assets/images/symptoms.png"
import checkup from "../assets/images/checkup.png"

const services = [
    {
        image: vaccine,
        name: "Vaccine",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: treatment,
        name: "Clinic",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: selfcare,
        name: "Self Care",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: laboratory,
        name: "Laboratory",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: treatment,
        name: "Treatment",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: pethealth,
        name: "Pet Health",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: symptoms,
        name: "Symptoms",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
    {
        image: checkup,
        name: "Check Up",
        body: "Lörem ipsum matkasse vir. Monogedade bevis"
    },
]

export default services